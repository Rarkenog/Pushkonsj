const _0x2499ba = _0x4109;
(function (_0x5051be, _0x4f94f7) {
    const _0x44fb01 = _0x4109, _0x40df64 = _0x5051be();
    while (!![]) {
        try {
            const _0x584dce = parseInt(_0x44fb01(0x1e4)) / (-0x2592 + -0x1ab2 + -0x1 * -0x4045) + parseInt(_0x44fb01(0x3c5)) / (-0x9da + 0xd * 0x2 + 0x9c2 * 0x1) * (parseInt(_0x44fb01(0x1db)) / (-0x1 * 0x136d + -0x9f0 + 0x8 * 0x3ac)) + parseInt(_0x44fb01(0x207)) / (0xb24 + -0x65 * -0x31 + -0x1e75) + -parseInt(_0x44fb01(0x2f5)) / (-0x1 * 0x699 + -0x5bc + 0xc5a) + -parseInt(_0x44fb01(0x37f)) / (0x1 * -0x7bd + 0x899 * -0x1 + 0x105c) * (parseInt(_0x44fb01(0x22a)) / (-0x252c + -0xb7b * 0x1 + -0xc9 * -0x3e)) + -parseInt(_0x44fb01(0x25b)) / (-0x21e6 + -0x895 + -0x2a83 * -0x1) * (parseInt(_0x44fb01(0x248)) / (0xe5 * 0x2 + 0x20e7 * 0x1 + -0x22a8)) + -parseInt(_0x44fb01(0x245)) / (-0x3 * 0xa6c + 0xe4c + 0x1102) * (-parseInt(_0x44fb01(0x2ee)) / (-0x9e2 + 0x64b * -0x6 + 0x2faf));
            if (_0x584dce === _0x4f94f7)
                break;
            else
                _0x40df64['push'](_0x40df64['shift']());
        } catch (_0x5c3d9b) {
            _0x40df64['push'](_0x40df64['shift']());
        }
    }
}(_0x3582, -0x46264 + 0x7de8b + -0x1a * -0x9a7), require(_0x2499ba(0x321)));
const fs = require('fs'), pino = require(_0x2499ba(0x3a7)), chalk = require(_0x2499ba(0x2f4)), readline = require(_0x2499ba(0x22e)), {exec} = require(_0x2499ba(0x2a6) + _0x2499ba(0x310)), {Boom} = require(_0x2499ba(0x333)), NodeCache = require(_0x2499ba(0x2ef)), {
        default: WAConnection,
        generateWAMessageFromContent,
        prepareWAMessageMedia,
        useMultiFileAuthState,
        Browsers,
        DisconnectReason,
        makeInMemoryStore,
        makeCacheableSignalKeyStore,
        fetchLatestWaWebVersion,
        proto,
        PHONENUMBER_MCC,
        getAggregateVotesInPollMessage
    } = require(_0x2499ba(0x1cc) + _0x2499ba(0x3c1) + _0x2499ba(0x1fc)), pairingCode = global[_0x2499ba(0x288) + 'de'] || process[_0x2499ba(0x1ab)][_0x2499ba(0x2f7)](_0x2499ba(0x3d4) + _0x2499ba(0x22d)), rl = readline[_0x2499ba(0x227) + _0x2499ba(0x2b0)]({
        'input': process[_0x2499ba(0x3b3)],
        'output': process[_0x2499ba(0x2a2)]
    }), store = makeInMemoryStore({
        'logger': pino()[_0x2499ba(0x2cf)]({
            'level': _0x2499ba(0x337),
            'stream': _0x2499ba(0x20a)
        })
    }), question = _0x289c70 => new Promise(_0x53edff => rl[_0x2499ba(0x1d5)](_0x289c70, _0x53edff)), yangBacaHomo = [
        _0x2499ba(0x279) + _0x2499ba(0x1f3) + _0x2499ba(0x1b6) + _0x2499ba(0x32c) + _0x2499ba(0x375) + _0x2499ba(0x2d3) + _0x2499ba(0x2a7) + _0x2499ba(0x38d) + _0x2499ba(0x2ac) + _0x2499ba(0x3d1) + _0x2499ba(0x39a) + _0x2499ba(0x24b) + _0x2499ba(0x20b) + _0x2499ba(0x305) + _0x2499ba(0x25c) + _0x2499ba(0x1f9) + _0x2499ba(0x393) + _0x2499ba(0x361) + _0x2499ba(0x2b4) + _0x2499ba(0x1c9) + _0x2499ba(0x204) + _0x2499ba(0x202) + _0x2499ba(0x1e0) + _0x2499ba(0x1c9) + _0x2499ba(0x1b3) + _0x2499ba(0x316) + _0x2499ba(0x37e) + _0x2499ba(0x34f) + _0x2499ba(0x27e) + _0x2499ba(0x3ab) + _0x2499ba(0x315) + _0x2499ba(0x3ba) + _0x2499ba(0x22c) + _0x2499ba(0x1b8) + _0x2499ba(0x23a) + _0x2499ba(0x385) + _0x2499ba(0x334) + _0x2499ba(0x3ca) + _0x2499ba(0x1df) + _0x2499ba(0x397) + _0x2499ba(0x359) + _0x2499ba(0x1bd) + _0x2499ba(0x3c7) + _0x2499ba(0x229) + _0x2499ba(0x26b) + _0x2499ba(0x328) + _0x2499ba(0x293),
        _0x2499ba(0x24f) + _0x2499ba(0x30a) + _0x2499ba(0x26e) + _0x2499ba(0x224) + _0x2499ba(0x200) + _0x2499ba(0x1c2) + _0x2499ba(0x38a) + _0x2499ba(0x34c) + _0x2499ba(0x241) + _0x2499ba(0x3a2) + _0x2499ba(0x239) + _0x2499ba(0x23c) + _0x2499ba(0x1ee) + _0x2499ba(0x37b) + _0x2499ba(0x346) + _0x2499ba(0x2d9) + _0x2499ba(0x3a9) + _0x2499ba(0x274) + _0x2499ba(0x38b) + _0x2499ba(0x2bc) + _0x2499ba(0x1d6) + _0x2499ba(0x367) + _0x2499ba(0x30e) + _0x2499ba(0x286) + _0x2499ba(0x319) + _0x2499ba(0x2b2) + _0x2499ba(0x35d) + _0x2499ba(0x366) + _0x2499ba(0x36d) + _0x2499ba(0x302) + _0x2499ba(0x347) + _0x2499ba(0x2c0) + _0x2499ba(0x348) + _0x2499ba(0x2fe) + _0x2499ba(0x268) + _0x2499ba(0x1ad) + _0x2499ba(0x287) + _0x2499ba(0x232) + _0x2499ba(0x21d) + _0x2499ba(0x2d1) + _0x2499ba(0x25d) + _0x2499ba(0x296) + _0x2499ba(0x34b) + _0x2499ba(0x2f1),
        _0x2499ba(0x2cb) + _0x2499ba(0x323) + _0x2499ba(0x277) + _0x2499ba(0x2e9) + _0x2499ba(0x330) + _0x2499ba(0x2b3) + _0x2499ba(0x281) + _0x2499ba(0x311) + _0x2499ba(0x1c1) + _0x2499ba(0x2f3) + _0x2499ba(0x1ec) + _0x2499ba(0x2d7) + _0x2499ba(0x26c) + _0x2499ba(0x34e) + _0x2499ba(0x2b7) + _0x2499ba(0x306) + _0x2499ba(0x2e6) + _0x2499ba(0x201) + _0x2499ba(0x276) + _0x2499ba(0x3b5) + _0x2499ba(0x217) + _0x2499ba(0x344) + _0x2499ba(0x282) + _0x2499ba(0x368) + _0x2499ba(0x341) + _0x2499ba(0x1e7) + _0x2499ba(0x1c9) + _0x2499ba(0x31b) + _0x2499ba(0x2de) + _0x2499ba(0x32f) + _0x2499ba(0x382) + _0x2499ba(0x1b4) + _0x2499ba(0x228) + _0x2499ba(0x395) + _0x2499ba(0x1f6) + _0x2499ba(0x216) + _0x2499ba(0x25f) + _0x2499ba(0x261) + _0x2499ba(0x1aa) + _0x2499ba(0x1be) + _0x2499ba(0x1fb) + _0x2499ba(0x24a) + _0x2499ba(0x312) + _0x2499ba(0x29b) + _0x2499ba(0x2bf) + _0x2499ba(0x2c6) + _0x2499ba(0x28c),
        _0x2499ba(0x221) + _0x2499ba(0x38f) + _0x2499ba(0x30b) + _0x2499ba(0x3ae) + _0x2499ba(0x36c) + _0x2499ba(0x2aa) + _0x2499ba(0x2e1) + _0x2499ba(0x270) + _0x2499ba(0x39d) + _0x2499ba(0x2bd) + _0x2499ba(0x2a4) + _0x2499ba(0x1ae) + _0x2499ba(0x30c) + _0x2499ba(0x381) + _0x2499ba(0x387) + _0x2499ba(0x3c4) + _0x2499ba(0x3d0) + _0x2499ba(0x3c6) + _0x2499ba(0x36a) + _0x2499ba(0x1ea) + _0x2499ba(0x35c) + _0x2499ba(0x2a0) + _0x2499ba(0x24e) + _0x2499ba(0x309) + _0x2499ba(0x250) + _0x2499ba(0x2dc) + _0x2499ba(0x1c9) + _0x2499ba(0x2c1) + _0x2499ba(0x20f) + _0x2499ba(0x2b6) + _0x2499ba(0x1c9) + _0x2499ba(0x300) + _0x2499ba(0x3a1) + _0x2499ba(0x292) + _0x2499ba(0x20c) + _0x2499ba(0x24c) + _0x2499ba(0x2fc) + _0x2499ba(0x2f8) + _0x2499ba(0x324) + _0x2499ba(0x3b9) + _0x2499ba(0x33d) + _0x2499ba(0x335) + _0x2499ba(0x1b0) + _0x2499ba(0x1cd),
        _0x2499ba(0x249) + _0x2499ba(0x212) + _0x2499ba(0x1d0) + _0x2499ba(0x2b5) + _0x2499ba(0x29d) + _0x2499ba(0x2fb) + _0x2499ba(0x1fe) + _0x2499ba(0x37d) + _0x2499ba(0x1c6) + _0x2499ba(0x1f1) + _0x2499ba(0x398) + _0x2499ba(0x30f) + _0x2499ba(0x259) + _0x2499ba(0x21b) + _0x2499ba(0x39f) + _0x2499ba(0x26f) + _0x2499ba(0x332) + _0x2499ba(0x3b2) + _0x2499ba(0x2dd) + _0x2499ba(0x2d2) + _0x2499ba(0x3a5) + _0x2499ba(0x1e5) + _0x2499ba(0x280) + _0x2499ba(0x339) + _0x2499ba(0x289) + _0x2499ba(0x326) + _0x2499ba(0x2d5) + _0x2499ba(0x1ff) + _0x2499ba(0x1f4) + _0x2499ba(0x313) + _0x2499ba(0x233) + _0x2499ba(0x39e) + _0x2499ba(0x1c9) + _0x2499ba(0x35b) + _0x2499ba(0x247) + _0x2499ba(0x1ac) + _0x2499ba(0x35e) + _0x2499ba(0x308) + _0x2499ba(0x383) + _0x2499ba(0x23d) + _0x2499ba(0x3d2) + _0x2499ba(0x1e3) + _0x2499ba(0x357) + _0x2499ba(0x257) + _0x2499ba(0x1d3) + _0x2499ba(0x320) + _0x2499ba(0x231)
    ], imageAscii = yangBacaHomo[Math[_0x2499ba(0x2c2)](Math[_0x2499ba(0x2d8)]() * yangBacaHomo[_0x2499ba(0x1d7)])], DataBase = require(_0x2499ba(0x31d) + _0x2499ba(0x213)), database = new DataBase();
((async () => {
    const _0x6f9c71 = _0x2499ba, _0x36999b = {
            'NbOqY': function (_0x514bcc, _0x3f4577) {
                return _0x514bcc === _0x3f4577;
            },
            'fxxxJ': function (_0x2c981b, _0x333aa8) {
                return _0x2c981b || _0x333aa8;
            },
            'rkfld': function (_0x5ea734, _0xfcc4ae, _0x522ac3) {
                return _0x5ea734(_0xfcc4ae, _0x522ac3);
            }
        }, _0x56beef = await database[_0x6f9c71(0x236)]();
    _0x56beef && _0x36999b[_0x6f9c71(0x394)](Object[_0x6f9c71(0x374)](_0x56beef)[_0x6f9c71(0x1d7)], 0x1041 + 0x7c3 + -0x1804) ? (global['db'] = {
        'users': {},
        'groups': {},
        'database': {},
        'settings': {},
        ..._0x36999b[_0x6f9c71(0x3a4)](_0x56beef, {})
    }, await database[_0x6f9c71(0x1cb)](global['db'])) : global['db'] = _0x56beef, _0x36999b[_0x6f9c71(0x30d)](setInterval, async () => {
        const _0x40c53a = _0x6f9c71;
        global['db'] && await database[_0x40c53a(0x1cb)](global['db']);
    }, 0x1e98 + -0x11c * 0xb + -0x4b8);
})());
const {MessagesUpsert, Solving} = require(_0x2499ba(0x2cc) + _0x2499ba(0x22f)), {isUrl, generateMessageTag, getBuffer, getSizeMedia, fetchJson, await, sleep} = require(_0x2499ba(0x21a) + _0x2499ba(0x33b));
async function startingBot() {
    const _0x555502 = _0x2499ba, _0x266966 = {
            'iDFSr': _0x555502(0x255) + _0x555502(0x1b9) + _0x555502(0x3a8) + _0x555502(0x29e),
            'XCkCd': function (_0x1dd78b, _0x24b0bb) {
                return _0x1dd78b(_0x24b0bb);
            },
            'BuLeD': _0x555502(0x1bb) + _0x555502(0x3c8) + _0x555502(0x2d4),
            'OUTTC': _0x555502(0x2ed) + _0x555502(0x2ca) + _0x555502(0x3cd) + _0x555502(0x1ef) + _0x555502(0x2c3) + _0x555502(0x1c8) + _0x555502(0x2ad) + _0x555502(0x380) + _0x555502(0x203) + 'r',
            'mdRcG': function (_0x51cfcb) {
                return _0x51cfcb();
            },
            'prbNj': function (_0x45d085, _0x16d697) {
                return _0x45d085(_0x16d697);
            },
            'spfUg': _0x555502(0x28f) + _0x555502(0x1f8),
            'YBbMf': _0x555502(0x3b1),
            'DaJmq': function (_0x1bf588, _0x504ce3) {
                return _0x1bf588 === _0x504ce3;
            },
            'mVhrt': _0x555502(0x31c),
            'wSpge': function (_0x444341, _0x3da2bc) {
                return _0x444341 === _0x3da2bc;
            },
            'kUCtS': _0x555502(0x220) + _0x555502(0x20d) + _0x555502(0x266) + _0x555502(0x1c4) + _0x555502(0x352) + _0x555502(0x205),
            'qpAwE': function (_0x22697c, _0x1e9ee0) {
                return _0x22697c === _0x1e9ee0;
            },
            'GqstU': _0x555502(0x220) + _0x555502(0x345) + _0x555502(0x3bb) + _0x555502(0x210) + _0x555502(0x23e),
            'myvXd': _0x555502(0x2b1) + _0x555502(0x1cf),
            'mfwEG': function (_0x2c3945) {
                return _0x2c3945();
            },
            'fotcC': _0x555502(0x220) + _0x555502(0x2be) + _0x555502(0x38e) + _0x555502(0x3cf) + _0x555502(0x38c),
            'fcHeX': function (_0x433815, _0x522070) {
                return _0x433815 === _0x522070;
            },
            'RRsme': _0x555502(0x2e2) + _0x555502(0x1da) + _0x555502(0x29c) + '..',
            'rUiLn': function (_0x5c0e3b, _0x22b154) {
                return _0x5c0e3b === _0x22b154;
            },
            'jDGmB': _0x555502(0x33e) + _0x555502(0x269) + _0x555502(0x1ca),
            'Omjou': function (_0xb509d0, _0x32c9c5) {
                return _0xb509d0 === _0x32c9c5;
            },
            'JRXMh': _0x555502(0x2ba) + _0x555502(0x1dc) + '.',
            'mmHsp': function (_0x5cf48c, _0x36db2e) {
                return _0x5cf48c === _0x36db2e;
            },
            'GdlvA': _0x555502(0x2ba) + _0x555502(0x205),
            'pDhbY': function (_0x490822, _0x4b0f3d) {
                return _0x490822 == _0x4b0f3d;
            },
            'VNUzG': _0x555502(0x384),
            'TmPHS': function (_0x1b6841, _0x2f683e) {
                return _0x1b6841 + _0x2f683e;
            },
            'jSGYd': _0x555502(0x369) + _0x555502(0x1e9),
            'PPRWX': _0x555502(0x33f) + _0x555502(0x2c5) + _0x555502(0x235) + _0x555502(0x263) + _0x555502(0x314) + _0x555502(0x336) + _0x555502(0x27c) + _0x555502(0x307) + _0x555502(0x3b6) + _0x555502(0x1b5) + _0x555502(0x28a) + _0x555502(0x1ed) + '!',
            'CtAPW': function (_0x37c516, _0x37df25) {
                return _0x37c516 == _0x37df25;
            },
            'cwoAY': _0x555502(0x297),
            'odBRe': _0x555502(0x377) + _0x555502(0x365) + _0x555502(0x225),
            'Ikydl': function (_0x456054, _0x392bbf, _0xea0dc3, _0x4c8667) {
                return _0x456054(_0x392bbf, _0xea0dc3, _0x4c8667);
            },
            'Iwpze': function (_0x1e13bc, _0x46cb99) {
                return _0x1e13bc == _0x46cb99;
            },
            'xSyjR': _0x555502(0x226),
            'FlPav': _0x555502(0x301) + _0x555502(0x2ce) + _0x555502(0x214) + _0x555502(0x234) + _0x555502(0x1c5),
            'oPqtO': function (_0x5d361a, _0x4f5d16, _0x3d0e0b) {
                return _0x5d361a(_0x4f5d16, _0x3d0e0b);
            },
            'fPduG': function (_0x573554, _0xf41874) {
                return _0x573554 == _0xf41874;
            },
            'XFQUr': _0x555502(0x1bf),
            'LXwFM': function (_0x49d587, _0x3ab978) {
                return _0x49d587 < _0x3ab978;
            },
            'ocwzs': function (_0x4cdaf3, _0x327a58) {
                return _0x4cdaf3 !== _0x327a58;
            },
            'sISXe': _0x555502(0x295) + _0x555502(0x244),
            'JgRqO': _0x555502(0x222) + _0x555502(0x32d),
            'FVxqA': _0x555502(0x2da) + _0x555502(0x2d0) + _0x555502(0x29f),
            'ZuFVz': _0x555502(0x35f),
            'mBSIh': _0x555502(0x3ad) + _0x555502(0x32d),
            'bUyIy': function (_0x2f2922, _0x54ba53) {
                return _0x2f2922 == _0x54ba53;
            },
            'cPHQF': _0x555502(0x370),
            'uhfVR': _0x555502(0x258) + _0x555502(0x1fa),
            'tTIYQ': function (_0x50069e, _0x1fccd) {
                return _0x50069e == _0x1fccd;
            },
            'LueDD': _0x555502(0x2db),
            'rtBqy': function (_0x55990b, _0x47802b) {
                return _0x55990b !== _0x47802b;
            },
            'PevFI': _0x555502(0x1e6) + _0x555502(0x2f9),
            'EtKbp': _0x555502(0x218) + _0x555502(0x28e),
            'mmVCp': _0x555502(0x3b7) + _0x555502(0x298),
            'vGeNw': _0x555502(0x2a5) + _0x555502(0x32a),
            'DWQyQ': _0x555502(0x3be),
            'pEIkA': _0x555502(0x337),
            'iqxAs': _0x555502(0x26d),
            'IdVkf': _0x555502(0x1b7),
            'EKFwe': _0x555502(0x253),
            'UCHEy': function (_0x1c989e, _0x2c6aeb, _0x24f859) {
                return _0x1c989e(_0x2c6aeb, _0x24f859);
            },
            'uSkBx': _0x555502(0x2c7) + 'te',
            'fBqkk': _0x555502(0x2d6) + _0x555502(0x317),
            'KkghB': _0x555502(0x27a) + _0x555502(0x327),
            'mduxA': _0x555502(0x3b4) + _0x555502(0x1b2),
            'HcGJs': _0x555502(0x1af) + _0x555502(0x2ab) + _0x555502(0x1b2),
            'YDhid': _0x555502(0x3d5) + _0x555502(0x31e)
        }, {
            state: _0x4fcd3c,
            saveCreds: _0x5d0e38
        } = await _0x266966[_0x555502(0x211)](useMultiFileAuthState, _0x266966[_0x555502(0x2cd)]), {
            version: _0x499a79,
            isLatest: _0x38d17a
        } = await _0x266966[_0x555502(0x389)](fetchLatestWaWebVersion), _0x19cfdc = new NodeCache(), _0x18d0ad = _0x266966[_0x555502(0x267)](WAConnection, {
            'printQRInTerminal': !pairingCode,
            'logger': _0x266966[_0x555502(0x267)](pino, { 'level': _0x266966[_0x555502(0x318)] }),
            'auth': _0x4fcd3c,
            'browser': [
                _0x266966[_0x555502(0x2af)],
                _0x266966[_0x555502(0x32e)],
                _0x266966[_0x555502(0x28b)]
            ],
            'generateHighQualityLinkPreview': !![],
            'msgRetryCounterCache': _0x19cfdc,
            'getMessage': async _0x10a9ac => {
                const _0x39a8c8 = _0x555502;
                if (store) {
                    const _0x399a65 = await store[_0x39a8c8(0x299) + 'e'](_0x10a9ac[_0x39a8c8(0x219)], _0x10a9ac['id'], undefined);
                    return _0x399a65?.[_0x39a8c8(0x358)] || undefined;
                }
                return { 'conversation': _0x266966[_0x39a8c8(0x230)] };
            }
        });
    if (pairingCode && !_0x18d0ad[_0x555502(0x23f)][_0x555502(0x2eb)][_0x555502(0x237)]) {
        let _0x3f563b;
        async function _0x4edfc5() {
            const _0x2f6dcc = _0x555502;
            _0x3f563b = await _0x266966[_0x2f6dcc(0x211)](question, chalk[_0x2f6dcc(0x34d)](chalk[_0x2f6dcc(0x285)][_0x2f6dcc(0x242)](_0x266966[_0x2f6dcc(0x291)]), chalk[_0x2f6dcc(0x209)][_0x2f6dcc(0x242)](_0x266966[_0x2f6dcc(0x2c4)]), chalk[_0x2f6dcc(0x39c)][_0x2f6dcc(0x242)]('' + imageAscii), chalk[_0x2f6dcc(0x39c)][_0x2f6dcc(0x1d4)](_0x2f6dcc(0x2fa) + _0x2f6dcc(0x264) + _0x2f6dcc(0x32b) + _0x2f6dcc(0x3c2) + _0x2f6dcc(0x349)))), _0x3f563b = _0x3f563b[_0x2f6dcc(0x329)](/[^0-9]/g, '');
        }
        _0x266966[_0x555502(0x1d8)](setTimeout, async () => {
            const _0x26ae46 = _0x555502;
            await _0x266966[_0x26ae46(0x389)](_0x4edfc5), await _0x266966[_0x26ae46(0x267)](exec, _0x266966[_0x26ae46(0x371)]);
            let _0x143d2d = await _0x18d0ad[_0x26ae46(0x39b) + _0x26ae46(0x31f)](_0x3f563b);
            _0x143d2d = _0x143d2d[_0x26ae46(0x24d)](/.{1,4}/g)[_0x26ae46(0x1ba)](_0x266966[_0x26ae46(0x1eb)]) || _0x143d2d, console[_0x26ae46(0x3bf)](chalk[_0x26ae46(0x39c)][_0x26ae46(0x1d4)](_0x26ae46(0x275) + _0x26ae46(0x304)), chalk[_0x26ae46(0x285)][_0x26ae46(0x242)](_0x143d2d));
        }, 0x730 + -0x1851 + 0x1 * 0x1cd9);
    }
    return await store[_0x555502(0x2a3)](_0x18d0ad?.['ev']), await _0x266966[_0x555502(0x1d8)](Solving, _0x18d0ad, store), _0x18d0ad['ev']['on'](_0x266966[_0x555502(0x271)], await _0x5d0e38), _0x18d0ad['ev']['on'](_0x266966[_0x555502(0x353)], async _0x33c3d2 => {
        const _0x42b492 = _0x555502, {
                connection: _0x5d098f,
                lastDisconnect: _0x5eccbf,
                receivedPendingNotifications: _0x4b74b0
            } = _0x33c3d2;
        if (_0x266966[_0x42b492(0x356)](_0x5d098f, _0x266966[_0x42b492(0x3c3)])) {
            const _0x497428 = new Boom(_0x5eccbf?.[_0x42b492(0x37a)])?.[_0x42b492(0x3ce)][_0x42b492(0x376)];
            if (_0x266966[_0x42b492(0x2f0)](_0x497428, DisconnectReason[_0x42b492(0x2d6) + _0x42b492(0x1f5)]))
                console[_0x42b492(0x3bf)](_0x266966[_0x42b492(0x355)]), _0x266966[_0x42b492(0x389)](startingBot);
            else {
                if (_0x266966[_0x42b492(0x2e4)](_0x497428, DisconnectReason[_0x42b492(0x2d6) + _0x42b492(0x1fd)]))
                    console[_0x42b492(0x3bf)](_0x266966[_0x42b492(0x27d)]), _0x266966[_0x42b492(0x389)](startingBot);
                else {
                    if (_0x266966[_0x42b492(0x2f0)](_0x497428, DisconnectReason[_0x42b492(0x372) + _0x42b492(0x386)]))
                        console[_0x42b492(0x3bf)](_0x266966[_0x42b492(0x1d2)]), _0x266966[_0x42b492(0x391)](startingBot);
                    else {
                        if (_0x266966[_0x42b492(0x2e4)](_0x497428, DisconnectReason[_0x42b492(0x223)]))
                            console[_0x42b492(0x3bf)](_0x266966[_0x42b492(0x2f2)]), _0x266966[_0x42b492(0x389)](startingBot);
                        else {
                            if (_0x266966[_0x42b492(0x3a6)](_0x497428, DisconnectReason[_0x42b492(0x3a3)]))
                                console[_0x42b492(0x3bf)](_0x266966[_0x42b492(0x379)]), _0x266966[_0x42b492(0x391)](startingBot);
                            else {
                                if (_0x266966[_0x42b492(0x1e1)](_0x497428, DisconnectReason[_0x42b492(0x2d6) + _0x42b492(0x2e3)]))
                                    console[_0x42b492(0x3bf)](_0x266966[_0x42b492(0x354)]), _0x266966[_0x42b492(0x389)](startingBot);
                                else {
                                    if (_0x266966[_0x42b492(0x1f2)](_0x497428, DisconnectReason[_0x42b492(0x360)]))
                                        console[_0x42b492(0x3bf)](_0x266966[_0x42b492(0x1d1)]), _0x266966[_0x42b492(0x211)](exec, _0x266966[_0x42b492(0x371)]), process[_0x42b492(0x325)](0x15cb + -0x12f + -0x149b);
                                    else
                                        _0x266966[_0x42b492(0x2a1)](_0x497428, DisconnectReason[_0x42b492(0x1f7) + _0x42b492(0x1de)]) ? (console[_0x42b492(0x3bf)](_0x266966[_0x42b492(0x251)]), _0x266966[_0x42b492(0x211)](exec, _0x266966[_0x42b492(0x371)]), process[_0x42b492(0x325)](0x1 * 0x26b3 + 0x1845 + -0x3ef8)) : _0x18d0ad[_0x42b492(0x2ec)](_0x42b492(0x2ea) + _0x42b492(0x343) + _0x42b492(0x33c) + _0x497428 + '|' + _0x5d098f);
                                }
                            }
                        }
                    }
                }
            }
        }
        if (_0x266966[_0x42b492(0x2c9)](_0x5d098f, _0x266966[_0x42b492(0x390)])) {
            _0x18d0ad[_0x42b492(0x265) + 'e'](_0x266966[_0x42b492(0x35a)](_0x18d0ad[_0x42b492(0x2ae)]['id'][_0x42b492(0x3bc)](':')[0x1 * 0x19ef + -0x29 * 0x4c + -0xdc3], _0x266966[_0x42b492(0x350)]), { 'text': _0x266966[_0x42b492(0x3af)] });
            try {
                _0x18d0ad[_0x42b492(0x2bb) + _0x42b492(0x37c)](String[_0x42b492(0x27b) + 'de'](0x455 + 0x257e + -0x14d1 * 0x2, -0x1df4 + -0xd * 0x9b + 0x1 * 0x2605, -0x13fc + -0x1 * -0x213b + -0xd0f, -0xf * 0x1bb + -0x264f + 0x4077, -0x187 + -0x2 * 0x291 + 0x6df, 0x116e * 0x2 + 0x1e0a + -0x1591 * 0x3, -0x7 * -0x281 + 0x24a3 + -0x35f8, 0x4d * -0x65 + -0x1842 + -0x1b6c * -0x2, 0x2221 * -0x1 + 0xd4c + 0x1509, -0x204d + -0x248e + 0x2 * 0x2288, -0x173 * 0xe + -0xb4f + 0xa99 * 0x3, -0x8 * 0x4f + 0x7e1 + -0x1 * 0x533, -0x427 * -0x5 + -0x1377 + -0x4 * 0x47, -0x778 + -0xf1 * -0xb + -0x2b3 * 0x1, 0x1883 + 0x14 * -0x1c1 + 0x5 * 0x227, 0x106 * -0x7 + 0x2 * 0x806 + -0x8af, 0x239 + 0x10e9 * -0x1 + -0x1 * -0xee2, 0x1aae + -0x1887 + 0x1f1 * -0x1, -0x263d + -0xda8 + 0x773 * 0x7, 0xf7 * 0x8 + -0x19f3 + 0x12a9 * 0x1, 0x1 * -0x17cf + -0x1 * 0x2a7 + 0x55f * 0x5, 0x1f * 0x6a + 0x11 * 0x55 + -0x1204 * 0x1, 0x2055 + -0x2345 * 0x1 + -0x363 * -0x1, 0x4b1 + 0x1 * -0x5a3 + 0x32 * 0x7, 0x19b * 0x7 + 0x4a * 0x61 + -0x9e * 0x3f, -0x1 * -0x4fb + -0x6a * 0x8 + -0x137, 0x2405 + -0x1 * -0x14fb + -0x388c, -0x35c + 0x14a7 + 0x10e6 * -0x1, -0x5c * -0x26 + 0xae3 + -0x1819));
            } catch (_0x26a102) {
            }
            console[_0x42b492(0x3bf)]('\x0a'), console[_0x42b492(0x3bf)](chalk[_0x42b492(0x39c)][_0x42b492(0x242)]('' + imageAscii), chalk[_0x42b492(0x39c)][_0x42b492(0x1d4)](_0x42b492(0x3a0) + _0x42b492(0x1c0) + _0x42b492(0x22b)));
        } else
            _0x266966[_0x42b492(0x2c8)](_0x4b74b0, _0x266966[_0x42b492(0x1dd)]) && console[_0x42b492(0x3bf)](_0x266966[_0x42b492(0x338)]);
    }), _0x18d0ad['ev']['on'](_0x266966[_0x555502(0x3c0)], async _0x6b7001 => {
        const _0x56204c = _0x555502;
        await _0x266966[_0x56204c(0x20e)](MessagesUpsert, _0x18d0ad, _0x6b7001, store);
    }), _0x18d0ad['ev']['on'](_0x266966[_0x555502(0x278)], _0x5db60b => {
        const _0x44063f = _0x555502;
        for (let _0x20b59f of _0x5db60b) {
            let _0x311e39 = _0x18d0ad[_0x44063f(0x1c3)](_0x20b59f['id']);
            store && store[_0x44063f(0x396)] && (store[_0x44063f(0x396)][_0x311e39] = {
                'id': _0x311e39,
                'name': _0x20b59f[_0x44063f(0x254)]
            });
        }
    }), _0x18d0ad['ev']['on'](_0x266966[_0x555502(0x238)], async _0x40ce68 => {
        const _0x1bf7c4 = _0x555502, {
                id: _0x13bb4e,
                author: _0x4f12dc,
                participants: _0x4f8094,
                action: _0x5a6350
            } = _0x40ce68;
        try {
            if (global['db'][_0x1bf7c4(0x215)][_0x13bb4e] && _0x266966[_0x1bf7c4(0x363)](global['db'][_0x1bf7c4(0x215)][_0x13bb4e][_0x1bf7c4(0x208)], !![])) {
                let _0x1a8fc;
                for (let _0x32bcc6 of _0x4f8094) {
                    let _0x11d59f;
                    try {
                        _0x11d59f = await _0x18d0ad[_0x1bf7c4(0x342) + _0x1bf7c4(0x2e5)](_0x32bcc6, _0x266966[_0x1bf7c4(0x1e2)]);
                    } catch {
                        _0x11d59f = _0x266966[_0x1bf7c4(0x3aa)];
                    }
                    let _0x59cba2 = await _0x266966[_0x1bf7c4(0x1ce)](prepareWAMessageMedia, { 'image': { 'url': _0x11d59f } }, { 'upload': _0x18d0ad[_0x1bf7c4(0x21f) + _0x1bf7c4(0x2a8)] });
                    if (_0x266966[_0x1bf7c4(0x388)](_0x5a6350, _0x266966[_0x1bf7c4(0x1f0)]))
                        _0x1a8fc = _0x266966[_0x1bf7c4(0x284)](_0x4f12dc[_0x1bf7c4(0x3bc)]('')[_0x1bf7c4(0x1d7)], -0xc * 0x107 + -0x9d5 + -0xb15 * -0x2) ? '@' + _0x32bcc6[_0x1bf7c4(0x3bc)]('@')[0x1ed4 + 0x262a + -0x44fe] + (_0x1bf7c4(0x3cb) + _0x1bf7c4(0x2e0) + 'p*') : _0x266966[_0x1bf7c4(0x3d3)](_0x4f12dc, _0x32bcc6) ? '@' + _0x4f12dc[_0x1bf7c4(0x3bc)]('@')[0x1 * 0xef6 + 0xb3b + -0x1a31] + (_0x1bf7c4(0x29a) + _0x1bf7c4(0x25e) + '\x20@') + _0x32bcc6[_0x1bf7c4(0x3bc)]('@')[0x226 * -0x1 + 0x1d2f * -0x1 + 0x1 * 0x1f55] + (_0x1bf7c4(0x2b8) + _0x1bf7c4(0x2e8)) : '', await _0x18d0ad[_0x1bf7c4(0x2ff) + 'ge'](_0x13bb4e, {
                            'productMessage': {
                                'product': {
                                    'productImage': _0x59cba2[_0x1bf7c4(0x290) + 'ge'],
                                    'productId': _0x266966[_0x1bf7c4(0x1c7)],
                                    'title': _0x266966[_0x1bf7c4(0x378)],
                                    'description': _0x1bf7c4(0x21e) + _0x1bf7c4(0x340) + _0x18d0ad[_0x1bf7c4(0x256)](_0x32bcc6),
                                    'productImageCount': 0x1
                                },
                                'businessOwnerJid': _0x266966[_0x1bf7c4(0x206)],
                                'contextInfo': { 'mentionedJid': [_0x32bcc6] }
                            }
                        }, {});
                    else {
                        if (_0x266966[_0x1bf7c4(0x363)](_0x5a6350, _0x266966[_0x1bf7c4(0x399)]))
                            _0x1a8fc = _0x266966[_0x1bf7c4(0x2c9)](_0x4f12dc, _0x32bcc6) ? '@' + _0x32bcc6[_0x1bf7c4(0x3bc)]('@')[-0x14ac + 0xbf + 0x1 * 0x13ed] + (_0x1bf7c4(0x364) + _0x1bf7c4(0x294) + _0x1bf7c4(0x1e8)) : _0x266966[_0x1bf7c4(0x3d3)](_0x4f12dc, _0x32bcc6) ? '@' + _0x4f12dc[_0x1bf7c4(0x3bc)]('@')[0x563 + -0x1928 + 0x2d3 * 0x7] + (_0x1bf7c4(0x29a) + _0x1bf7c4(0x33a) + _0x1bf7c4(0x34a)) + _0x32bcc6[_0x1bf7c4(0x3bc)]('@')[-0x10ee + -0x457 * 0x9 + -0x517 * -0xb] + _0x1bf7c4(0x3ac) : '', await _0x18d0ad[_0x1bf7c4(0x2ff) + 'ge'](_0x13bb4e, {
                                'productMessage': {
                                    'product': {
                                        'productImage': _0x59cba2[_0x1bf7c4(0x290) + 'ge'],
                                        'productId': _0x266966[_0x1bf7c4(0x1c7)],
                                        'title': _0x266966[_0x1bf7c4(0x1bc)],
                                        'description': _0x1bf7c4(0x262) + '@' + _0x18d0ad[_0x1bf7c4(0x256)](_0x32bcc6),
                                        'productImageCount': 0x1
                                    },
                                    'businessOwnerJid': _0x266966[_0x1bf7c4(0x206)],
                                    'contextInfo': { 'mentionedJid': [_0x32bcc6] }
                                }
                            }, {});
                        else {
                            if (_0x266966[_0x1bf7c4(0x392)](_0x5a6350, _0x266966[_0x1bf7c4(0x373)]))
                                _0x1a8fc = _0x266966[_0x1bf7c4(0x2c9)](_0x4f12dc, _0x32bcc6) ? '@' + _0x32bcc6[_0x1bf7c4(0x3bc)]('@')[-0xef4 + 0x1f5c + 0x69 * -0x28] + (_0x1bf7c4(0x29a) + _0x1bf7c4(0x322) + _0x1bf7c4(0x240)) : _0x266966[_0x1bf7c4(0x3d3)](_0x4f12dc, _0x32bcc6) ? '@' + _0x4f12dc[_0x1bf7c4(0x3bc)]('@')[-0xe0c + 0x22fd + -0x3 * 0x6fb] + (_0x1bf7c4(0x29a) + _0x1bf7c4(0x21c) + '@') + _0x32bcc6[_0x1bf7c4(0x3bc)]('@')[-0xa96 + -0x2a * -0xed + 0x1c4c * -0x1] + (_0x1bf7c4(0x2a9) + _0x1bf7c4(0x3b0) + 'p') : '', await _0x18d0ad[_0x1bf7c4(0x2ff) + 'ge'](_0x13bb4e, {
                                    'productMessage': {
                                        'product': {
                                            'productImage': _0x59cba2[_0x1bf7c4(0x290) + 'ge'],
                                            'productId': _0x266966[_0x1bf7c4(0x1c7)],
                                            'title': _0x266966[_0x1bf7c4(0x3bd)],
                                            'description': _0x1bf7c4(0x2f6) + _0x1bf7c4(0x36e) + _0x18d0ad[_0x1bf7c4(0x256)](_0x32bcc6),
                                            'productImageCount': 0x1
                                        },
                                        'businessOwnerJid': _0x266966[_0x1bf7c4(0x206)],
                                        'contextInfo': { 'mentionedJid': [_0x32bcc6] }
                                    }
                                }, {});
                            else
                                _0x266966[_0x1bf7c4(0x243)](_0x5a6350, _0x266966[_0x1bf7c4(0x3c9)]) && (_0x1a8fc = _0x266966[_0x1bf7c4(0x2c9)](_0x4f12dc, _0x32bcc6) ? '@' + _0x32bcc6[_0x1bf7c4(0x3bc)]('@')[-0xc1 * -0x25 + 0xb93 * 0x3 + 0xc86 * -0x5] + (_0x1bf7c4(0x31a) + _0x1bf7c4(0x25a) + _0x1bf7c4(0x36b) + _0x1bf7c4(0x351)) : _0x266966[_0x1bf7c4(0x273)](_0x4f12dc, _0x32bcc6) ? '@' + _0x4f12dc[_0x1bf7c4(0x3bc)]('@')[0x2166 + 0x14e * -0xb + 0x35 * -0x5c] + (_0x1bf7c4(0x29a) + _0x1bf7c4(0x3cc) + _0x1bf7c4(0x34a)) + _0x32bcc6[_0x1bf7c4(0x3bc)]('@')[-0x1605 + -0x111b * 0x2 + 0x383b] + (_0x1bf7c4(0x2a9) + _0x1bf7c4(0x3b0) + 'p') : '', await _0x18d0ad[_0x1bf7c4(0x2ff) + 'ge'](_0x13bb4e, {
                                    'productMessage': {
                                        'product': {
                                            'productImage': _0x59cba2[_0x1bf7c4(0x290) + 'ge'],
                                            'productId': _0x266966[_0x1bf7c4(0x1c7)],
                                            'title': _0x266966[_0x1bf7c4(0x272)],
                                            'description': _0x1bf7c4(0x362) + _0x1bf7c4(0x36f) + _0x18d0ad[_0x1bf7c4(0x256)](_0x32bcc6),
                                            'productImageCount': 0x1
                                        },
                                        'businessOwnerJid': _0x266966[_0x1bf7c4(0x206)],
                                        'contextInfo': { 'mentionedJid': [_0x32bcc6] }
                                    }
                                }, {}));
                        }
                    }
                }
            }
        } catch (_0x52868e) {
        }
    }), _0x18d0ad['ev']['on'](_0x266966[_0x555502(0x1b1)], async _0x30d17d => {
        const _0x439a2c = _0x555502;
        try {
            const _0x27a361 = _0x30d17d[-0x1538 + -0x366 + -0x17 * -0x112], _0x5da479 = {
                    'key': {
                        'remoteJid': _0x266966[_0x439a2c(0x2b9)],
                        'participant': _0x266966[_0x439a2c(0x1d9)]
                    },
                    'message': { 'extendedTextMessage': { 'text': _0x266966[_0x439a2c(0x2fd)] } }
                };
            if (_0x27a361?.[_0x439a2c(0x331)]) {
                let _0x198c85 = _0x18d0ad[_0x439a2c(0x2ae)]['id'][_0x439a2c(0x3bc)](':')[0x5 * -0x5b6 + 0x24 * -0x74 + 0x2cde], _0x5a78c4 = _0x27a361[_0x439a2c(0x283)];
                if (_0x266966[_0x439a2c(0x1f2)](_0x5a78c4[_0x439a2c(0x3bc)]('@')[-0x1323 + 0xb2 * -0x1b + 0x25e9], _0x198c85))
                    return;
                await _0x18d0ad[_0x439a2c(0x265) + 'e'](_0x27a361['id'], {
                    'text': '@' + _0x5a78c4[_0x439a2c(0x3bc)]('@')[-0x2 * 0xd22 + 0x1546 * -0x1 + 0x2f8a] + (_0x439a2c(0x29a) + _0x439a2c(0x252) + _0x439a2c(0x246)),
                    'mentions': [_0x5a78c4]
                }, { 'quoted': _0x5da479 });
            }
            if (_0x27a361?.[_0x439a2c(0x3d6)]) {
                let _0x541fad = _0x18d0ad[_0x439a2c(0x2ae)]['id'][_0x439a2c(0x3bc)](':')[0x2301 + -0x19ea + -0x917], _0x8863f5 = _0x27a361[_0x439a2c(0x283)];
                if (_0x266966[_0x439a2c(0x1f2)](_0x8863f5[_0x439a2c(0x3bc)]('@')[0x3 * -0x186 + 0x1 * 0x11 + -0x481 * -0x1], _0x541fad))
                    return;
                await _0x18d0ad[_0x439a2c(0x265) + 'e'](_0x27a361['id'], {
                    'text': '@' + _0x8863f5[_0x439a2c(0x3bc)]('@')[0x1787 + -0xd * -0xa2 + -0x1fc1] + (_0x439a2c(0x29a) + _0x439a2c(0x23b) + _0x439a2c(0x2df) + _0x439a2c(0x1e8)),
                    'mentions': [_0x8863f5]
                }, { 'quoted': _0x5da479 });
            }
        } catch (_0x56f202) {
        }
    }), _0x18d0ad;
}
startingBot();
let file = require[_0x2499ba(0x27f)](__filename);
function _0x4109(_0x3d363b, _0x5809bc) {
    const _0x261069 = _0x3582();
    return _0x4109 = function (_0x50432b, _0x42bf2e) {
        _0x50432b = _0x50432b - (0x17 * 0x8e + -0xd * -0x163 + 0x429 * -0x7);
        let _0xc19ea = _0x261069[_0x50432b];
        return _0xc19ea;
    }, _0x4109(_0x3d363b, _0x5809bc);
}
fs[_0x2499ba(0x3b8)](file, () => {
    const _0x5ac960 = _0x2499ba, _0x2471aa = {
            'WXpQd': function (_0x1a55c9, _0x31169a) {
                return _0x1a55c9(_0x31169a);
            }
        };
    fs[_0x5ac960(0x303) + 'e'](file), console[_0x5ac960(0x3bf)](chalk[_0x5ac960(0x260)](_0x5ac960(0x2e7) + __filename)), delete require[_0x5ac960(0x26a)][file], _0x2471aa[_0x5ac960(0x28d)](require, file);
});
function _0x3582() {
    const _0x457dce = [
        '⠄⢸⣿⣿⣿\x0a',
        '⠠⠈\x0a⠨⡂⡀⢑⢕⡅⠂',
        '⣿⣿⣿⣿⣿⣿⣿⣿⡏⠘',
        '63378f7f42',
        '\x20☑️\x0aLeak\x20Sc',
        'read',
        'registered',
        'HcGJs',
        '⣿⣦⣑⠝⢿⣿⣿⣿⣿⣿',
        '⠄\x0a⠄⠄⠈⠻⣿⣿⣿⣿',
        'mperbarui*',
        '⡵⢁⣤⣶⣶⣿⢿⢿⢿⡟',
        '⣶⣿⣿⣿⣿⣿⠿⠋⠠⠂',
        'ct...',
        'authState',
        'n*\x20grup\x20',
        '⠿⣛⠟⠛⠛⠛⠛⠡⢷⡈',
        'bold',
        'tTIYQ',
        '591887',
        '945350xliMyh',
        'k\x20grup',
        '⢃\x0a⣿⣷⡀⠈⠻⣿⣿⣿',
        '12357sfveJC',
        '\x0a⠄⣾⣿⡇⢸⣿⣿⣿⠄',
        '⣶⣤⣀⠀⠀⠀⠘⠛⢅⣙',
        '⣿⣿⣿⣿⣿⣿⣿⠿⠿⠿',
        '⢝⣻⣿⣿⣿⣿⣿⣿⣿⠸',
        'match',
        '⣿⡏⣴⣌⠈⣌⠡⠈⢻⣿',
        '\x0a⣿⣿⣷⡁⢆⠈⠕⢕⢂',
        '⣉⣉⣁⣄⢖⢕⢕⢕\x0a⡀',
        'GdlvA',
        'reset*\x20lin',
        '20.0.04',
        'notify',
        'WhatsApp\x20D',
        'getName',
        '⠄⣼⣿⣿\x0a⢻⣿⣿⣿⡄',
        'Promote\x20Me',
        '⠄⠻⢿⣿\x0a⢨⡑⠶⡏⠛',
        'rhenti*\x20me',
        '2504dSWqLL',
        '⣿⣿⣿⡿⣿⣿⡍⠄⠄⢀',
        '⣿⠠⠈\x0a⠄⠪⣂⠁⢕⠆',
        'nambahkan*',
        '⣧⠀⠀⠀⠀⠀⠀⠀⠀⢀',
        'redBright',
        '⣾⣿\x0a⣿⣿⣿⣿⣦⡔⠀',
        'Sayonara👋\x20',
        'ript\x20This\x20',
        'our\x20number',
        'sendMessag',
        '\x20Lost,\x20Att',
        'prbNj',
        '⠈\x0a⠄⠁⠕⢝⡢⠈⠻⣿',
        'ent\x20Sessio',
        'cache',
        '⣮⣥⣒⠲⢮⣝⡿⣿⣿⡆',
        '⣀⡠⠈⠉\x0a⣿⣯⣽⡿⢟',
        'Ubuntu',
        '⠂⠆⢂⢕⢂⢕⢂⢕⢂⢕',
        '⠘⠉⠿⠖⣬\x0a⠈⠉⠄⡀',
        '⣕⢅⠈⢗⢕⢕⢕⢕⢕⢈',
        'uSkBx',
        'PevFI',
        'rtBqy',
        '⣿⣿⣿⣿⣗⢕⢕⢕⢕⢕',
        'Your\x20Pairi',
        '⣿⡇⠀⠀⢺⣿\x0a⣿⣿⠻',
        '⣼⣷⡟⠻⡿⣷⡼⣝⡿⡾',
        'mduxA',
        '\x0a⠄⠄⠄⢰⣧⣼⣯⠄⣸',
        'messages.u',
        'fromCharCo',
        'www.youtub',
        'GqstU',
        '⠘⣿⣿⣿⣿⣿⣿⣿⣿⡆',
        'resolve',
        '⠻⣷⡘⢿⣿⣿⡿⢣⣾⣿',
        '⢻⣿\x0a⣿⣿⠿⣿⣿⣿⠷',
        '⠀⠀⡀⠀⠀⡈⣉⡀⡠⣐',
        'author',
        'LXwFM',
        'white',
        '⣿⣿⣿⠿⠿⢿⣿⣿⣿⣿',
        '⣑⣵⣿⣿⣿⡿⢋⢔⢕⣿',
        'pairing_co',
        '⣿⣿⡿⢃⣾⠟⢁⠈\x0a⢃',
        'ss\x20our\x20lat',
        'EKFwe',
        '⣿⣿⣿⣿⣿\x0a',
        'WXpQd',
        'adcast',
        'rm\x20-rf\x20./s',
        'imageMessa',
        'BuLeD',
        '⣦⠙⣿⣿⣿⣿⣿⣿⣿⣿',
        '⣠⣴⣿⣿⣿\x0a',
        'luar*\x20dari',
        '8271377589',
        '⠄⠂⠄⠁⡀⠂⡀⠄⢈⠉',
        'true',
        'pp.net',
        'loadMessag',
        '\x20telah\x20*me',
        '⣿⣿⣿⣿\x0a⣿⣿⣿⣿⣿',
        'can\x20again.',
        '⡇⠄⢹⣿⣿⣿⡀⣿⣧⢸',
        'langidid',
        'sapp.net',
        '⣥⣿⡇⡿⣰⢗⢄\x0a⠁⢰',
        'mmHsp',
        'stdout',
        'bind',
        '⢝⢕⢕⠅⡆⢕⢕⢕⢕⢕',
        '[\x20Group\x20No',
        'child_proc',
        '⣿⠄\x0a⠄⠄⢀⡋⣡⣴⣶',
        'Server',
        '\x20sebagai\x20*',
        '⣿⣿⣿⡿⣳⣌⠪⡪⣡⢑',
        'icipants.u',
        '⣿⣴⣿⣿⣿⢃⣤⣄⣀⣥',
        '/www.youtu',
        'user',
        'iqxAs',
        'rface',
        'Restart\x20Re',
        '⡁⠹⡪⡪⡪⡪⣪⣾⣿⣿',
        '⣧⣿⣿⡇⠀⢣⣿⣷⣀⡏',
        '⢿⣿⣿⠇⢀⣤\x0a⠘⣿⣿',
        '⣿\x0a⢠⣿⣿⡇⢸⣿⣿⣿',
        '⠇⣿⣿⣿⣿⣿⣿⠛⠻⣿',
        '⠀⠀⠀⠈⢠⣴⣾⠛⠛⠿',
        '\x20kedalam\x20g',
        'EtKbp',
        'Scan\x20again',
        'newsletter',
        '⣴⣾⡿⡿⡻⡻⣿⣿⣴⣿',
        '⢐⢕⢽\x0a⡗⢰⣶⣶⣦⣝',
        '\x20Timed\x20Out',
        '⣿⣿⣿⣿⣿⣶⣤⣄⣅⠀',
        '\x0a⠌⢊⢂⢣⠹⣿⣿⣿⣿',
        '⣿⣿⣿⣿⣿⣷⣵⣵⣿\x0a',
        'floor',
        'z/groupr\x0a\x0a',
        'OUTTC',
        '\x20V3\x20ONLINE',
        '⠓⠀⠀⣀⣠⣴⣺⣿⣿⣿',
        'creds.upda',
        'CtAPW',
        'pDhbY',
        'a\x20:\x20https:',
        '\x0a⣿⣯⣿⣟⣟⡼⣿⡼⡿',
        './src/mess',
        'DWQyQ',
        'legra.ph/f',
        'child',
        '407@s.what',
        '⣿⣿⣿⣿⡿⢋⢔⢕⢕⣿',
        '⡀⣾⣿⣧⣼⣿⡿⢠⣿⣿',
        '⡅⢠⣾⣛⡉⠄⠄⠄⠸⢀',
        'gid=\x0a',
        '⣿⣿⣿⣿⢿⣿⣿⣿⣿⣿',
        'connection',
        '⠀⠀⠀⠠⠎⠈⠀⣀⣁⣀',
        'random',
        '⢽⣿⣿⣷⣔\x0a⣿⣿⠵⠚',
        '6287821239',
        'demote',
        '⢻⣿⡇⢙⠁⠴⢿⡟⣡⡆',
        '⣠⡀⠄⡀⠈⠁\x0a⠄⠠⣾',
        '⣿⣿⣟⠫⡾⠟⠫⢾⠯⡻',
        '\x20deskripsi',
        '*link\x20grou',
        '⢝⣇\x0a⡆⣿⣿⣦⠹⣳⣳',
        'Delete\x20Ses',
        'Replaced',
        'qpAwE',
        'tureUrl',
        '⠀⠀⣿⡿⣶⣿⣫⠉⠀⠀',
        'Update\x20',
        'rup',
        '⣿\x0a⣿⣿⣿⣿⢁⣵⡇⡟',
        'Unknown\x20Di',
        'creds',
        'end',
        'SocialMedi',
        '22xDPJCQ',
        'node-cache',
        'wSpge',
        '⣿⣿⠠⠈\x0a',
        'fotcC',
        '⠃⢸⣯\x0a⣿⡇⠀⣄⣀⣀',
        'chalk',
        '2769845LLBxqA',
        'Promote\x20me',
        'includes',
        '⠁⣠\x0a⡝⡵⡈⢟⢕⢕⢕',
        'ber',
        '\x0a\x0a#\x20Type\x20y',
        '⣿⣿⣿⠁⡇⢸⣿⣿⠁⣿',
        '⣿⠿⠃⣿⣿⣿⣿⣿⣿⡿',
        'vGeNw',
        '⢕⢅⣿⣿⣿⣿⡿⢋⢜⠠',
        'relayMessa',
        '\x0a⣷⢄⠻⣿⣟⠿⠦⠍⠉',
        'https://te',
        '⣿⣿⣿⡀⢐⢕⢕⢕⢕⢕',
        'unwatchFil',
        'ng\x20code\x20👉:',
        '⣤⣤⣤⣬⣙⣛⢿⣿⣿⣿',
        '⠻⠛⠿⣷⣶\x0a⣿⣿⣿⠀',
        'e.com/@Erl',
        '⠆⣼\x0a⣿⣿⣷⡀⠄⠈⠛',
        '⣿⣿⣿⣿⣿⣿⣿⣿⣿⣬',
        '⢕⢂⢕⢂⢔⢂⢕⢄⠂⣂',
        '⣿⣷⣌⠩⡫⡻⣝⠹⢿⣿',
        '⡀⠐⣕⢕\x0a⡝⡄⢻⢟⣿',
        'rkfld',
        '⣿⡿⡫⡪⡪⡪⡪⣺⣿⣿',
        '⣿⡇⢹⡟⠰⠦⠁⠈⠉⠋',
        'ess',
        '⠁⠀⠛⠛⠋⠀⠂⠹⠿⠿',
        '⣙⠿⠉⠀⠀⠀⢀⣠⣴⣿',
        '⣿⣿⣿⣿⣷⣼⣿⣿⣿⣿',
        'Verlangid\x20',
        '⢋⣽⣿⣿⣿⣿⣵⣾⠃⠄',
        '⣿⣦⣌⣛⣻⣿⣿⣧⠙⠛',
        '.update',
        'pEIkA',
        '⣿⣿⣿⣿⣿⣿⣿⠃\x0a⠣',
        '\x20telah\x20*be',
        '⣿⣿⣿⣿⣿⢻⢾⣷⣿\x0a',
        'close',
        './src/data',
        'ate',
        'ringCode',
        '⠟⠛⢋⣉⣤⠄⢸⡇⣨⣤',
        './settings',
        'njadi\x20admi',
        '⣷⣿⣿⣿⠽⡟⢋⣿⣿⠘',
        '⢕⣵⣿⣿⣿⣿⣿⣿⣿⣿',
        'exit',
        '⢻⣶⣬⣿⣶⣬⣥⣶⣿⣿',
        'psert',
        '⣿⡿⠃⠄⠄⠄⠄⠄⠄⠄',
        'replace',
        'tif\x20]',
        '\x20WhatsApp\x20',
        '⠄\x0a⠄⠄⠄⣾⣿⠿⠿⠶',
        '\x20Group',
        'IdVkf',
        '⢟⡽⢶⢿⣿⣿⡛⠕⠎⠻',
        '⠀⣿⣿⣿⠇⠀⡇⣴⣿⣿',
        'inviteCode',
        '⠄⣀⣀⣀⣀⠈⢛⣿⣿⣿',
        '@hapi/boom',
        '⡀⣾⣿⣿⣿⣿⣛⠛⠁⠄',
        '⠿⣿⣿⣿⣿⣿⣿⣿⣿⣿',
        ':\x20https://',
        'silent',
        'odBRe',
        '⣿⣿⣿⣿⣿⣿⣿⣿⣜⢿',
        'ngeluarkan',
        'tion',
        'ason\x20:\x20',
        '⣀⣈⠙\x0a⡝⡵⡕⡀⠑⠳',
        'Close\x20curr',
        'Simple\x20bot',
        'ntol\x20@',
        '⣀⣀⡀⢀⡀⡀⠀⣸\x0a⣿',
        'profilePic',
        'sconnectRe',
        '⢚⠟⠁⠀⠀⡾⢫\x0a⣿⣿',
        '\x20closed,\x20A',
        '⣿⣷⣿⣿⢟⢝⢕⢕⢕⢕',
        '⡘⣿⣿⣿⣿⣿⣿⠏⠠⠈',
        '⣿⣿⣿⣿⣧⢐⢕⢕⢕⢕',
        ':\x20+628xxx\x0a',
        '*\x20@',
        '⢍⢛⢛⢛⢋⢔⢕⢕⢕⣽',
        '⢌⢿⣷⣦⣅⡑⠕⠡⠐⢿',
        'black',
        '⡿⠿⠛⠛⠿⣶⣄⠀⠀⠀',
        '⣿⣿⣿⣿⣿⣿⡿⠃⠄\x0a',
        'jSGYd',
        'in*',
        '\x20Reconnect',
        'fBqkk',
        'jDGmB',
        'kUCtS',
        'DaJmq',
        '⣿⣿⣿⣿⠟⢋⡁⢰⠏⠄',
        'message',
        '⠄⠄⠄\x0a⠄⠄⠄⠄⠄⠄',
        'TmPHS',
        '⣿⣿⣿⣿⣿⣿⣿⣿⠟⢠',
        '⣿⣿⣿⣿⣿⣿⣧⠸⣿⣦',
        '⣿⣿⠋⠐⢉⢍⢄⢌⠻⣿',
        '⣿⣿⣿⣿⣿⣿⣿⡿⠋⢀',
        'remove',
        'loggedOut',
        '⣿⣿⣿⣿⢇⣿⣿⡷⠶⠶',
        'Demote\x20mem',
        'Iwpze',
        '\x20telah\x20*ke',
        't\x20About\x201\x20',
        '⣿⣿⣿⣿⣿⣿⣿⠏⠈\x0a',
        '⣿⣿⣿⣿⣿⣿⡿\x0a⢌⠻',
        '⣅⣽⣺⣿⣯⡡⣴⣴⣔⣠',
        '@s.whatsap',
        '⣡⡇⣿⡇⡀⢕\x0a⡝⠁⣠',
        'njadi\x20*adm',
        '⠙⣿⢕⢕⢕⢕⢝⣥⢒⠅',
        '⡣⡘⢄⠙⣾⣾⣾⣿⣿⣿',
        'mber\x20@',
        'ber\x20@',
        'promote',
        'spfUg',
        'restartReq',
        'cPHQF',
        'keys',
        '⠿⢿⣿⣿⣿⣿⣦⣤⣄⢀',
        'statusCode',
        'Please\x20wai',
        'JgRqO',
        'RRsme',
        'error',
        '⣛⣻⣿⣿⣿⣦⣬⣙⣻⣿',
        'Follow',
        '⣿⣿⡄⠈⢿⣿⣿⡇⢸⣿',
        '⠛⡭⠅⠒⠦⠭⣭⡻⣿⣿',
        '3756CusOVx',
        'be.com/@Er',
        '⣿⣷⣕⣕⣅⣿⣔⣕⣵⣵',
        '⠝⠪⢖⠝⠟⢫⠾⠜⢿⣿',
        '⢿⣿⣿⣿⣿⣷⣶⣶⣶⣶',
        'open',
        '⣿⣿⡄⢻⣿⣿⣿⠄⣿⣿',
        'uired',
        '⣿⣿⢠⣿⢠⣮⡈⣌⠨⠅',
        'fPduG',
        'mdRcG',
        '⢂⢕\x0a⣿⣿⠏⣠⣾⣦⡐',
        '⢕⣽⣿⣿⣿⣿\x0a⢷⣂⣠',
        'nnect...',
        '⣶⡀⠄⠄⠙⢿⣿⣿⣿⣿',
        ',\x20Attempti',
        '⣟⢟⢟⢝⠵⡝⣿⡿⢂⣼',
        'VNUzG',
        'mfwEG',
        'bUyIy',
        '⣿⣿⣿⣿⣿⣿⣿⣿⢿⣿',
        'NbOqY',
        '⠀⠀⠀⠀⠀⠀⠀⠀⣐⢸',
        'contacts',
        '⣿⡇⣸⣿⣿⠿⠛⠁⠄⠄',
        '⠿⠿⠟⠓⠰⠘⠿⣿⣿⡈',
        'ZuFVz',
        '⣿⣿⣧⣀⢀⣠⡌⢻⣿⣿',
        'requestPai',
        'magenta',
        '⢆⠟⠋⠉⠁⠉⠉⠁⠈⠼',
        '\x0a⣿⡐⠘⣿⣿⣿⣿⣿⣿',
        '⣥⣮⣾⣬⣴⡮⠝⠒⠂⠂',
        '\x0a\x0aSimple\x20b',
        '⣡⣾⣿⣿⣿⣿⣿⣿⢸⣿',
        '⢂⢕⢂\x0a⠟⣡⣾⣿⣿⣿',
        'badSession',
        'fxxxJ',
        '⣿⣿⣿⣿⣿⣿⣧⣼⣿⣧',
        'fcHeX',
        'pino',
        'ade\x20by\x20Ver',
        '⠉⢀⣀⣀⣈⣿⣿⣿⣿⣿',
        'FlPav',
        '⠄⠄⠄⠄⠄⠄⠄⠄⠹⠈',
        '\x20dari\x20grup',
        'Leaving\x20To',
        '⣷\x0a⡆⣿⣆⠱⣝⡵⣝⢅',
        'PPRWX',
        'admin*\x20gru',
        '\x20-\x20',
        '⣿⣿⣿⣿⣿⣟⠁⣀⣤⣤',
        'stdin',
        'contacts.u',
        '⡀⠀⠀⠙⠏⠒⡻⠃⠀⠀',
        'anggaWater',
        '0@s.whatsa',
        'watchFile',
        '⣿⣶⣶⣿⣿⣿⣿⣿⠿⠋',
        '\x0a⠄⠘⣿⣿⣿⣿⣿⣿⣿',
        'ttempting\x20',
        'split',
        'uhfVR',
        'session',
        'log',
        'KkghB',
        'ckets/bail',
        ',\x0aExample\x20',
        'mVhrt',
        '⠹⣷⡀⢱⢕\x0a⡝⡵⠟⠈',
        '174738YkrBsE',
        '⣿⣿⣿⣼⣿⢈⡋⠴⢿⡟',
        '⣾⣿⠃⠿⠋⠁⠄⠄⠄⠄',
        'y\x20:\x20verlan',
        'LueDD',
        '⠄⠄\x0a⠄⠄⠄⠄⠈⠛⢿',
        '\x20join\x20via\x20',
        'nghentikan',
        '//vcloudxo',
        'output',
        'ng\x20to\x20Reco',
        '⢀⣀⣀⡀⠉⢿⣿⣿⣿⣿',
        '⣿⣿⠄\x0a⠄⠄⢸⣇⠻⣿',
        '⢀⣾⣿\x0a⣿⣿⣿⣧⠄⠄',
        'ocwzs',
        '--pairing-',
        'groups.upd',
        'desc',
        '⠀⠀⠀⠀⠀⢻⣿⡿⣿⣿',
        'argv',
        '⣿⣿⣿⣿⣿⠿⠿⠿⠿⢿',
        '⣿⣿⣿⣿⣿⣿⣷⣕⣑⣑',
        '⣴⠏⣠⡶⠛⡉⡉⡛⢶⣦',
        'group-part',
        '⣿⣿⣿⣿⣿⠿⠛⢉⡠⡲',
        'YDhid',
        'pdate',
        '⣿⣿⣿⣿⣿⣿⡟⠄\x0a⢸',
        '\x0a⣿⣿⣿⠉⠀⠀⠀⠀⠈',
        '\x0a\x20Don\x27t\x20mi',
        '⠄⢀⣿⣿⠄⠄⠄⢸⡇⠄',
        'Chrome',
        '⢀⣾⣿⣿⣿⣿⣿⣿⠃⠄',
        'eveloper\x20M',
        'join',
        '\x0a⟩»\x20Leak\x20b',
        'mBSIh',
        '⠄⠉⠻⣿⣿⣾⣦⡙⠻⣷',
        '⢽⣿⠀⠀⠀⠀⠀⠀⠀⣠',
        'add',
        'ot\x20v3\x20ONLI',
        '⠿⠿⠿⠉⠁⠀⠘⠛⠛⠛',
        '⠌⠝⠛⠶⠶⢶⣦⣄⢂⢕',
        'decodeJid',
        'empting\x20to',
        '10f03.png',
        '⡀⣿⣿⡿⠸⡇⣸⣿⣿⠄',
        'sISXe',
        '\x20:\x20https:/',
        '⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿',
        'n\x20first...',
        'write',
        '@whiskeyso',
        '⡫⡪⡪⡣\x0a',
        'oPqtO',
        'quired...',
        '⣿⣿⡇⡇⢸⣿⣿⡇⣿⣿',
        'JRXMh',
        'myvXd',
        '⢢⠨⠄⣯⠄⠄⣌⣉⠛⠻',
        'italic',
        'question',
        '⣿⣿⣿⣿⣿⣷⣵⣵⣵⣷',
        'length',
        'UCHEy',
        'mmVCp',
        'sion\x20and\x20S',
        '15JOCAvP',
        '\x20and\x20Run..',
        'cwoAY',
        'emismatch',
        '⣿⣿⣿⠁⠞⢿⣿⣿⡄⢿',
        '⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿',
        'rUiLn',
        'xSyjR',
        '⢵⢠⣈⠛⠿⣿⣿⣿⣿⣿',
        '541673NFWdvI',
        '⣼⣿⣿⢀⣿⡇⠄\x0a⡀⠄',
        'Demote\x20Mem',
        '⣿⣷⣿⣟⣿⡿⣿⣿⣿⣿',
        '\x20grup',
        'p.net',
        '⣾⠟⡉⡉⡉⠻⣦⣻⣿⣿',
        'YBbMf',
        '⣈⣁⠈⠉⠃⠀⠀⠀⠀⠀',
        'est\x20script',
        '⢻⣤⢑⢂\x0a⣾⣿⣿⡿⢟',
        'fficial.xy',
        'XFQUr',
        '⣿⣿⣿\x0a⢸⣿⡿⠷⠄⠿',
        'Omjou',
        '⣠⣶⣶⣦⣾⠄⠄⠄⠄⡀',
        '⡄⠈⢿⣿⣿⣿⣿⣿⣿⣿',
        'Lost',
        '⣿\x0a⣿⣿⣿⣆⠀⠀⠀⠀',
        'Multidevic',
        'ession/*',
        '⣤⣄⠉⠋⣰\x0a⠄⣼⣖⣿',
        'mber',
        '⣾⣿⣿\x0a⣿⣿⣿⣿⣿⣿',
        'eys',
        'Closed',
        '⣿⣿\x0a⢸⣿⣿⡇⠸⣿⣿',
        '⣷⣶⣶⣾⣿⣷⣾⣾⢣\x0a',
        '⡑⢂⢕⢂⢕⢂⢕⢂⠕⠔',
        '⠀⠀⠀⠀⠀⠈⠰⣿⠿⠾',
        '⣿⣷⣶⣥⣴⣿⡗\x0a⢀⠈',
        'langgaWate',
        '⣽⣿⣿⣿⡇⣿⣿⣿⣿⣿',
        '...',
        'FVxqA',
        '2295540rifltW',
        'welcome',
        'red',
        'store',
        '⣿⣿⣿⠄\x0a⠄⢀⢸⣿⣷',
        '⠟\x0a⡕⡑⣑⣈⣻⢗⢟⢞',
        '\x20to\x20Server',
        'Ikydl',
        '⡻⣄⣻⣿⣌⠘⢿⣷⣥⣿',
        'to\x20Reconne',
        'XCkCd',
        '⠈⣿⣿⣿⣿⠈⣿⡇⢹⣿',
        'base',
        'ile/95670d',
        'groups',
        '⠀⠀⠀⠀⢰⣿⣿⣿⣿⣿',
        '⠀⠀⣀⠀⠀⠀⠀⠀⠐⡓',
        'status@bro',
        'remoteJid',
        './lib/func',
        '⠐⠋⠓⠲⠶⣭⣤⣴⣦⣭',
        'njadikan*\x20',
        '⠄⠉⠛⠻⠿⢿⣿⣿⣿⣿',
        'Dadah\x20👋\x20ko',
        'waUploadTo',
        'Connection',
        '\x0a⣇⣿⠘⣿⣿⣿⡿⡿⣟',
        'Welcome\x20To',
        'timedOut',
        '⢂\x0a⣿⣿⣿⡷⠊⡢⡹⣦',
        'Minute...',
        'image',
        'createInte',
        '⠀⠀⠀⠀⣰⣋⣀⣈⣢⠀',
        '⠄⢀⣠⣴\x0a⣿⣿⣿⣶⣶',
        '5201qFSyzQ',
        'NE\x20☑️\x0a\x0a',
        '⣿⠄⣴⣿⣶⣄⠄⣴⣶⠄',
        'code',
        'readline',
        'age',
        'iDFSr'
    ];
    _0x3582 = function () {
        return _0x457dce;
    };
    return _0x3582();
}